#include "Cavalo.h"
#include "Tabuleiro.h"

std::vector<Movimento> Cavalo::getMovimentosPossiveis(const Tabuleiro& tabuleiro) const {
    std::vector<Movimento> movimentos;

    // Todos os 8 movimentos poss�veis em "L" do cavalo
    const int dr[] = { -2, -2, -1, -1,  1,  1,  2,  2 };
    const int dc[] = { -1,  1, -2,  2, -2,  2, -1,  1 };

    for (int i = 0; i < 8; ++i) {
        Posicao novaPos = { m_pos.linha + dr[i], m_pos.col + dc[i] };

        // Verifica se a posi��o � v�lida (dentro do tabuleiro e n�o � buraco)
        if (tabuleiro.ePosValida(novaPos)) {
            Peca* pecaNoLocal = tabuleiro.getPecaEm(novaPos);

            // Pode mover se estiver vazio OU se for pe�a inimiga (captura)
            if (pecaNoLocal == nullptr || pecaNoLocal->getCor() != m_cor) {
                movimentos.push_back({ m_pos, novaPos });
            }
            // (Se for pe�a aliada, n�o faz nada)
        }
    }

    return movimentos;
}

std::unique_ptr<Peca> Cavalo::clone() const {
    return std::make_unique<Cavalo>(*this);
}