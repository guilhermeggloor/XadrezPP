#include "Rei.h"
#include "Tabuleiro.h" 

std::vector<Movimento> Rei::getMovimentosPossiveis(const Tabuleiro& tabuleiro) const {
    std::vector<Movimento> movimentos;
    Cor corInimiga = (m_cor == Cor::BRANCA) ? Cor::PRETA : Cor::BRANCA;

    for (int dr = -1; dr <= 1; ++dr) {
        for (int dc = -1; dc <= 1; ++dc) {
            if (dr == 0 && dc == 0) continue;

            Posicao novaPos = { m_pos.linha + dr, m_pos.col + dc };

            if (!tabuleiro.ePosValida(novaPos)) {
                continue;
            }

            Peca* pecaNoLocal = tabuleiro.getPecaEm(novaPos);

            // 1. Verifica se � pe�a aliada
            if (pecaNoLocal != nullptr && pecaNoLocal->getCor() == m_cor) {
                continue; // Pula pe�a aliada
            }

            // 2. Se a casa est� VAZIA ou tem INIMIGO, ela S� � v�lida
            //    se N�O FOR ATACADA.

            //    (O bug anterior estava aqui: `eAtacadoPor` falhava
            //     ao checar a pr�pria casa da pe�a).

            //    Vamos tentar a simula��o (Fix 3.7) que � mais robusta.

            Tabuleiro tabSimulado = tabuleiro;
            if (pecaNoLocal != nullptr) {
                // Se for captura, remove a pe�a do tabuleiro simulado
                tabSimulado.removerPecaEm(novaPos); // Requer a fun��o da Fase 3.7
            }

            // Verifica se a casa (agora vazia) � atacada
            if (!tabSimulado.eAtacadoPor(novaPos, corInimiga)) {
                movimentos.push_back({ m_pos, novaPos });
            }
        }
    }
    return movimentos;
}

std::unique_ptr<Peca> Rei::clone() const {
    return std::make_unique<Rei>(*this);
}