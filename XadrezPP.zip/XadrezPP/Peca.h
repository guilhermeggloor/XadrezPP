// Peca.h
#pragma once

#include <vector>
#include <memory>
#include "Core.h"

// Pr�-declara��o para evitar inclus�o circular.
// Peca precisa saber que Tabuleiro existe, mas n�o precisa de todos os detalhes.
class Tabuleiro;

class Peca {
protected:
    Posicao m_pos;
    Cor m_cor;
    TipoPeca m_tipo;

public:
    // Construtor
    Peca(Posicao pos, Cor cor, TipoPeca tipo)
        : m_pos(pos), m_cor(cor), m_tipo(tipo) {
    }

    // Destrutor virtual � essencial para classes base polim�rficas
    virtual ~Peca() = default;

    // (M�todos Virtuais Puros) 

    virtual std::vector<Movimento> getMovimentosPossiveis(const Tabuleiro& tabuleiro) const = 0;

    virtual std::unique_ptr<Peca> clone() const = 0;

    // Getters e Setters Comuns 
    Posicao getPosicao() const { return m_pos; }
    Cor getCor() const { return m_cor; }
    TipoPeca getTipo() const { return m_tipo; }

    void setPosicao(Posicao novaPos) { m_pos = novaPos; }
};